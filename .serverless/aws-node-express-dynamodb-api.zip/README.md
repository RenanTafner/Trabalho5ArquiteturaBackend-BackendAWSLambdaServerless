# Trabalho Final Disciplina Arquitetura Backend

## Backend em AWS Lambda Serverless

Integrantes do grupo:

* Luiz Gabriel Santos Fernandes;
* Raife Ferreira Paiva;
* Renan Carlos Silva Braz Tafner.

Aplicação já hospedada utilizando o site do Serverless e a AWS Lambda no link:

https://2knh0oc42g.execute-api.us-east-1.amazonaws.com
