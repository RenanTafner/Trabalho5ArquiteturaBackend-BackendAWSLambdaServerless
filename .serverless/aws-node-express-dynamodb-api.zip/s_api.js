
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'renantafner',
  applicationName: 'aws-node-express-dynamodb-api',
  appUid: 'hwXJW9WzDcx3SrBMsZ',
  orgUid: '77a51563-04f3-4132-80c8-a29c8852d926',
  deploymentUid: '3e8edc52-75d5-44bc-9fcc-73303fe9e2e7',
  serviceName: 'aws-node-express-dynamodb-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-express-dynamodb-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}